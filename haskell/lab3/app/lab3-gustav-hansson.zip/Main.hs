-- Gustav Hansson

module Main where

import Lib

import TestExpr
import TestStatement
import TestProgram

main :: IO ()
-- main = putStr(s2)
main = print(rp2)
